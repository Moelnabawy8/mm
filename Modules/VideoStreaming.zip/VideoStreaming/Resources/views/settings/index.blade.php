@extends('layouts.admin')
@section('page-title')
    {{ __('Video Streaming Settings') }}
@endsection

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('videostreaming.index') }}">{{ __('Video Streaming') }}</a></li>
    <li class="breadcrumb-item">{{ __('Settings') }}</li>
@endsection

@section('content')
<div class="row">
    <div class="col-lg-8">
        <!-- Google Drive Settings -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="ti ti-brand-google-drive me-2"></i>{{ __('Google Drive Configuration') }}
                </h5>
            </div>
            <div class="card-body">
                <form id="googleDriveForm">
                    <div class="mb-3">
                        <label class="form-label">{{ __('Client ID') }}</label>
                        <input type="text" name="google_drive[client_id]" class="form-control" 
                               value="{{ $settings['google_drive']['client_id'] }}" 
                               placeholder="{{ __('Enter Google OAuth Client ID') }}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">{{ __('Client Secret') }}</label>
                        <input type="password" name="google_drive[client_secret]" class="form-control" 
                               value="{{ $settings['google_drive']['client_secret'] ?? '' }}"
                               placeholder="{{ __('Enter Google OAuth Client Secret') }}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">{{ __('Folder ID') }}</label>
                        <input type="text" name="google_drive[folder_id]" class="form-control" 
                               value="{{ $settings['google_drive']['folder_id'] }}"
                               placeholder="{{ __('Google Drive folder ID for video storage') }}">
                        <small class="text-muted">{{ __('All videos will be stored in this folder') }}</small>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            @if($settings['google_drive']['connected'])
                                <span class="badge bg-success">
                                    <i class="ti ti-check me-1"></i>{{ __('Connected') }}
                                </span>
                            @else
                                <span class="badge bg-warning">
                                    <i class="ti ti-alert-circle me-1"></i>{{ __('Not Connected') }}
                                </span>
                            @endif
                        </div>
                        <button type="button" class="btn btn-outline-primary" onclick="testGoogleDrive()">
                            <i class="ti ti-plug me-1"></i>{{ __('Test Connection') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- HLS Settings -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="ti ti-video me-2"></i>{{ __('HLS Streaming Settings') }}
                </h5>
            </div>
            <div class="card-body">
                <form id="hlsForm">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">{{ __('Segment Duration (seconds)') }}</label>
                                <input type="number" name="hls[segment_duration]" class="form-control" 
                                       value="{{ $settings['hls']['segment_duration'] ?? 10 }}" min="2" max="30">
                                <small class="text-muted">{{ __('Recommended: 6-10 seconds') }}</small>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">{{ __('Key Rotation Interval') }}</label>
                                <input type="number" name="hls[key_rotation_interval]" class="form-control" 
                                       value="{{ $settings['hls']['key_rotation_interval'] ?? 5 }}" min="1" max="50">
                                <small class="text-muted">{{ __('Rotate encryption key every N segments') }}</small>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="hls[encryption_enabled]" 
                                   id="hlsEncryption" {{ ($settings['hls']['encryption_enabled'] ?? true) ? 'checked' : '' }}>
                            <label class="form-check-label" for="hlsEncryption">
                                {{ __('Enable AES-128 Encryption') }}
                            </label>
                        </div>
                        <small class="text-muted">{{ __('Strongly recommended for content protection') }}</small>
                    </div>
                </form>
            </div>
        </div>

        <!-- Security Settings -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="ti ti-shield me-2"></i>{{ __('Security Settings') }}
                </h5>
            </div>
            <div class="card-body">
                <form id="securityForm">
                    <div class="mb-3">
                        <label class="form-label">{{ __('Signed URL Expiry (seconds)') }}</label>
                        <input type="number" name="security[signed_url_expiry]" class="form-control" 
                               value="{{ $settings['security']['signed_url_expiry'] ?? 3600 }}" min="300" max="86400">
                        <small class="text-muted">{{ __('How long streaming URLs remain valid (300-86400 seconds)') }}</small>
                    </div>
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="security[enable_domain_lock]" 
                                   id="domainLock" {{ ($settings['security']['enable_domain_lock'] ?? true) ? 'checked' : '' }}>
                            <label class="form-check-label" for="domainLock">
                                {{ __('Enable Domain Lock') }}
                            </label>
                        </div>
                        <small class="text-muted">{{ __('Restrict video playback to specific domains') }}</small>
                    </div>
                    <div class="mb-3" id="allowedDomainsContainer">
                        <label class="form-label">{{ __('Allowed Domains') }}</label>
                        <textarea name="security[allowed_domains]" class="form-control" rows="3" 
                                  placeholder="example.com,subdomain.example.com">{{ $settings['security']['allowed_domains'] ?? '' }}</textarea>
                        <small class="text-muted">{{ __('Comma-separated list of domains allowed to embed videos') }}</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">{{ __('Max Concurrent Views per Session') }}</label>
                        <input type="number" name="security[max_concurrent_views]" class="form-control" 
                               value="{{ $settings['security']['max_concurrent_views'] ?? 3 }}" min="1" max="10">
                    </div>
                </form>
            </div>
        </div>

        <!-- Player Settings -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="ti ti-player-play me-2"></i>{{ __('Player Settings') }}
                </h5>
            </div>
            <div class="card-body">
                <form id="playerForm">
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="player[watermark_enabled]" 
                                   id="watermarkEnabled" {{ ($settings['player']['watermark_enabled'] ?? true) ? 'checked' : '' }}>
                            <label class="form-check-label" for="watermarkEnabled">
                                {{ __('Enable Watermark') }}
                            </label>
                        </div>
                    </div>
                    <div class="mb-3" id="watermarkTextContainer">
                        <label class="form-label">{{ __('Default Watermark Text') }}</label>
                        <input type="text" name="player[watermark_text]" class="form-control" 
                               value="{{ $settings['player']['watermark_text'] ?? '' }}"
                               placeholder="{{ __('Your brand name') }}">
                    </div>
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="player[disable_right_click]" 
                                   id="disableRightClick" {{ ($settings['player']['disable_right_click'] ?? true) ? 'checked' : '' }}>
                            <label class="form-check-label" for="disableRightClick">
                                {{ __('Disable Right Click') }}
                            </label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="player[disable_devtools]" 
                                   id="disableDevtools" {{ ($settings['player']['disable_devtools'] ?? true) ? 'checked' : '' }}>
                            <label class="form-check-label" for="disableDevtools">
                                {{ __('Block DevTools Detection') }}
                            </label>
                        </div>
                        <small class="text-muted">{{ __('Stop video playback if browser developer tools are opened') }}</small>
                    </div>
                </form>
            </div>
        </div>

        <!-- Save Button -->
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-end">
                    <button type="button" class="btn btn-primary" onclick="saveSettings()">
                        <i class="ti ti-device-floppy me-1"></i>{{ __('Save All Settings') }}
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
        <!-- System Status -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">{{ __('System Status') }}</h5>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span>{{ __('FFmpeg') }}</span>
                    <span id="ffmpegStatus">
                        <span class="spinner-border spinner-border-sm"></span>
                    </span>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span>{{ __('Google Drive') }}</span>
                    <span id="driveStatus">
                        @if($settings['google_drive']['connected'] ?? false)
                            <span class="badge bg-success">{{ __('Connected') }}</span>
                        @else
                            <span class="badge bg-warning">{{ __('Not Connected') }}</span>
                        @endif
                    </span>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <span>{{ __('HLS Encryption') }}</span>
                    <span class="badge bg-{{ ($settings['hls']['encryption_enabled'] ?? true) ? 'success' : 'warning' }}">
                        {{ ($settings['hls']['encryption_enabled'] ?? true) ? __('Enabled') : __('Disabled') }}
                    </span>
                </div>
            </div>
        </div>

        <!-- Output Qualities -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">{{ __('Output Qualities') }}</h5>
            </div>
            <div class="card-body">
                @foreach(($settings['processing']['output_qualities'] ?? []) as $name => $quality)
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span>
                            <strong>{{ strtoupper($name) }}</strong>
                            <span class="text-muted small">({{ $quality['width'] }}x{{ $quality['height'] }})</span>
                        </span>
                        <span class="badge bg-secondary">{{ $quality['bitrate'] }}</span>
                    </div>
                @endforeach
            </div>
        </div>

        <!-- Help -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">{{ __('Setup Guide') }}</h5>
            </div>
            <div class="card-body">
                <ol class="small mb-0">
                    <li class="mb-2">{{ __('Create a Google Cloud project and enable Drive API') }}</li>
                    <li class="mb-2">{{ __('Create OAuth 2.0 credentials and configure consent screen') }}</li>
                    <li class="mb-2">{{ __('Enter Client ID and Secret above') }}</li>
                    <li class="mb-2">{{ __('Create a folder in Google Drive and copy its ID') }}</li>
                    <li class="mb-2">{{ __('Install FFmpeg on your server') }}</li>
                    <li>{{ __('Test connection and start uploading videos') }}</li>
                </ol>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Check FFmpeg status
    fetch('{{ route("videostreaming.settings.test-ffmpeg") }}', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Accept': 'application/json'
        }
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById('ffmpegStatus').innerHTML = data.success 
            ? `<span class="badge bg-success">v${data.version}</span>`
            : '<span class="badge bg-danger">{{ __("Not Found") }}</span>';
    })
    .catch(() => {
        document.getElementById('ffmpegStatus').innerHTML = '<span class="badge bg-danger">{{ __("Error") }}</span>';
    });

    // Toggle domains container
    document.getElementById('domainLock').addEventListener('change', function() {
        document.getElementById('allowedDomainsContainer').style.display = this.checked ? 'block' : 'none';
    });

    // Toggle watermark text
    document.getElementById('watermarkEnabled').addEventListener('change', function() {
        document.getElementById('watermarkTextContainer').style.display = this.checked ? 'block' : 'none';
    });
});

function testGoogleDrive() {
    const btn = event.target;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>{{ __("Testing...") }}';

    fetch('{{ route("videostreaming.settings.test-drive") }}', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Accept': 'application/json'
        }
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            toastr.success(data.message);
            document.getElementById('driveStatus').innerHTML = '<span class="badge bg-success">{{ __("Connected") }}</span>';
        } else {
            toastr.error(data.message);
        }
    })
    .catch(() => {
        toastr.error('{{ __("Connection test failed") }}');
    })
    .finally(() => {
        btn.disabled = false;
        btn.innerHTML = '<i class="ti ti-plug me-1"></i>{{ __("Test Connection") }}';
    });
}

function saveSettings() {
    const forms = ['googleDriveForm', 'hlsForm', 'securityForm', 'playerForm'];
    const data = {};

    forms.forEach(formId => {
        const form = document.getElementById(formId);
        const formData = new FormData(form);
        
        for (let [key, value] of formData.entries()) {
            // Parse nested keys like google_drive[client_id]
            const match = key.match(/(\w+)\[(\w+)\]/);
            if (match) {
                if (!data[match[1]]) data[match[1]] = {};
                data[match[1]][match[2]] = value;
            } else {
                data[key] = value;
            }
        }
    });

    // Handle checkboxes
    data.hls = data.hls || {};
    data.hls.encryption_enabled = document.getElementById('hlsEncryption').checked;
    
    data.security = data.security || {};
    data.security.enable_domain_lock = document.getElementById('domainLock').checked;
    
    data.player = data.player || {};
    data.player.watermark_enabled = document.getElementById('watermarkEnabled').checked;
    data.player.disable_right_click = document.getElementById('disableRightClick').checked;
    data.player.disable_devtools = document.getElementById('disableDevtools').checked;

    fetch('{{ route("videostreaming.settings.update") }}', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            toastr.success(data.message);
        } else {
            toastr.error(data.message);
        }
    })
    .catch(() => {
        toastr.error('{{ __("Failed to save settings") }}');
    });
}
</script>
@endpush
