@extends('layouts.admin')

@section('page-title')
    {{ __('Connect Social Media Account') }}
@endsection

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">{{ __('Dashboard') }}</a></li>
    <li class="breadcrumb-item"><a href="{{ route('marketing.index') }}">{{ __('Marketing') }}</a></li>
    <li class="breadcrumb-item"><a href="{{ route('marketing.accounts') }}">{{ __('Accounts') }}</a></li>
    <li class="breadcrumb-item active">{{ __('Connect') }}</li>
@endsection

@section('content')
    <div class="row justify-content-center">
        <div class="col-xl-8">
            <div class="card">
                <div class="card-header">
                    <h5>{{ __('Connect New Account') }}</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('marketing.accounts.store') }}" method="POST">
                        @csrf
                        
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label class="form-label">{{ __('Platform') }}</label>
                                <select name="platform" class="form-control" required>
                                    <option value="">{{ __('Select Platform') }}</option>
                                    <option value="facebook">{{ __('Facebook') }}</option>
                                    <option value="instagram">{{ __('Instagram') }}</option>
                                    <option value="twitter">{{ __('Twitter / X') }}</option>
                                    <option value="linkedin">{{ __('LinkedIn') }}</option>
                                    <option value="youtube">{{ __('YouTube') }}</option>
                                    <option value="tiktok">{{ __('TikTok') }}</option>
                                </select>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="form-label">{{ __('Account Name') }}</label>
                                <input type="text" name="account_name" class="form-control" placeholder="{{ __('My Business Page') }}" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">{{ __('Account ID') }} <small class="text-muted">({{ __('Optional') }})</small></label>
                                <input type="text" name="account_id" class="form-control" placeholder="123456789">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">{{ __('Page ID') }} <small class="text-muted">({{ __('Optional') }})</small></label>
                                <input type="text" name="page_id" class="form-control" placeholder="987654321">
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="form-label">{{ __('Page Name') }} <small class="text-muted">({{ __('Optional') }})</small></label>
                                <input type="text" name="page_name" class="form-control" placeholder="{{ __('My Business Page Name') }}">
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="form-label">{{ __('Access Token') }} <small class="text-muted">({{ __('Optional') }})</small></label>
                                <textarea name="access_token" class="form-control" rows="3" placeholder="{{ __('Paste your access token here') }}"></textarea>
                                <small class="text-muted">{{ __('Get your access token from the platform\'s developer console') }}</small>
                            </div>
                        </div>

                        <div class="alert alert-info">
                            <i class="ti ti-info-circle"></i>
                            <strong>{{ __('Note') }}:</strong> {{ __('To use Meta API features, you need to configure META_APP_ID and META_APP_SECRET in your .env file') }}
                        </div>

                        <div class="text-end">
                            <a href="{{ route('marketing.accounts') }}" class="btn btn-secondary">{{ __('Cancel') }}</a>
                            <button type="submit" class="btn btn-primary">{{ __('Connect Account') }}</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
