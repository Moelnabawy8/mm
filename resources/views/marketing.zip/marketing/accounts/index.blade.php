@extends('layouts.admin')

@section('page-title')
    {{ __('Social Media Accounts') }}
@endsection

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">{{ __('Dashboard') }}</a></li>
    <li class="breadcrumb-item"><a href="{{ route('marketing.index') }}">{{ __('Marketing') }}</a></li>
    <li class="breadcrumb-item active">{{ __('Accounts') }}</li>
@endsection

@section('action-button')
    <a href="{{ route('marketing.accounts.create') }}" class="btn btn-sm btn-primary">
        <i class="ti ti-plus"></i> {{ __('Connect Account') }}
    </a>
@endsection

@section('content')
    <div class="row">
        @forelse($accounts as $account)
            <div class="col-xl-4 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="me-3">
                                <i class="{{ $account->platform_icon }}" style="font-size: 3rem; color: {{ $account->platform_color }};"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h5 class="mb-0">{{ $account->account_name }}</h5>
                                <small class="text-muted">{{ ucfirst($account->platform) }}</small>
                            </div>
                            <div>
                                <span class="badge bg-{{ $account->status == 'active' ? 'success' : ($account->status == 'expired' ? 'danger' : 'warning') }}">
                                    {{ ucfirst($account->status) }}
                                </span>
                            </div>
                        </div>

                        @if($account->page_name)
                            <div class="mb-3">
                                <small class="text-muted">{{ __('Page') }}:</small>
                                <p class="mb-0">{{ $account->page_name }}</p>
                            </div>
                        @endif

                        <div class="mb-3">
                            <small class="text-muted">{{ __('Campaigns') }}:</small>
                            <p class="mb-0"><strong>{{ $account->campaigns->count() }}</strong></p>
                        </div>

                        <div class="mb-3">
                            <small class="text-muted">{{ __('Connected') }}:</small>
                            <p class="mb-0">{{ $account->created_at->diffForHumans() }}</p>
                        </div>

                        <div class="d-flex gap-2">
                            <a href="{{ route('marketing.accounts.edit', $account->id) }}" class="btn btn-sm btn-info flex-fill">
                                <i class="ti ti-edit"></i> {{ __('Edit') }}
                            </a>
                            <form action="{{ route('marketing.accounts.delete', $account->id) }}" method="POST" class="flex-fill" onsubmit="return confirm('{{ __('Are you sure?') }}');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger w-100">
                                    <i class="ti ti-trash"></i> {{ __('Delete') }}
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        @empty
            <div class="col-12">
                <div class="card">
                    <div class="card-body text-center py-5">
                        <i class="ti ti-share text-muted" style="font-size: 5rem;"></i>
                        <h4 class="mt-3">{{ __('No Accounts Connected') }}</h4>
                        <p class="text-muted">{{ __('Connect your social media accounts to start managing campaigns') }}</p>
                        <a href="{{ route('marketing.accounts.create') }}" class="btn btn-primary mt-3">
                            <i class="ti ti-plus"></i> {{ __('Connect Account') }}
                        </a>
                    </div>
                </div>
            </div>
        @endforelse
    </div>
@endsection
