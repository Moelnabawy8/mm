@extends('layouts.admin')

@section('page-title')
    {{ __('Marketing Analytics') }}
@endsection

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">{{ __('Dashboard') }}</a></li>
    <li class="breadcrumb-item"><a href="{{ route('marketing.index') }}">{{ __('Marketing') }}</a></li>
    <li class="breadcrumb-item active">{{ __('Analytics') }}</li>
@endsection

@section('action-button')
    <div class="btn-group">
        <a href="{{ route('marketing.analytics', ['range' => 7]) }}" class="btn btn-sm {{ $dateRange == 7 ? 'btn-primary' : 'btn-outline-primary' }}">7 {{ __('Days') }}</a>
        <a href="{{ route('marketing.analytics', ['range' => 30]) }}" class="btn btn-sm {{ $dateRange == 30 ? 'btn-primary' : 'btn-outline-primary' }}">30 {{ __('Days') }}</a>
        <a href="{{ route('marketing.analytics', ['range' => 90]) }}" class="btn btn-sm {{ $dateRange == 90 ? 'btn-primary' : 'btn-outline-primary' }}">90 {{ __('Days') }}</a>
    </div>
@endsection

@push('theme-script')
    <script src="{{ asset('assets/libs/apexcharts/dist/apexcharts.min.js') }}"></script>
@endpush

@section('content')
    <div class="row">
        @foreach($accounts as $account)
            <div class="col-xl-4 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <i class="{{ $account->platform_icon }}" style="font-size: 2.5rem; color: {{ $account->platform_color }};"></i>
                            <div class="ms-3">
                                <h5 class="mb-0">{{ $account->account_name }}</h5>
                                <small class="text-muted">{{ ucfirst($account->platform) }}</small>
                            </div>
                        </div>

                        @php
                            $accountInsights = $insights->where('account_id', $account->id);
                            $totalFollowers = $accountInsights->last()->followers ?? 0;
                            $totalEngagement = $accountInsights->sum('total_engagement');
                            $avgEngagementRate = $accountInsights->avg('engagement_rate') ?? 0;
                        @endphp

                        <div class="row text-center">
                            <div class="col-4">
                                <h6 class="mb-0">{{ number_format($totalFollowers) }}</h6>
                                <small class="text-muted">{{ __('Followers') }}</small>
                            </div>
                            <div class="col-4">
                                <h6 class="mb-0">{{ number_format($totalEngagement) }}</h6>
                                <small class="text-muted">{{ __('Engagement') }}</small>
                            </div>
                            <div class="col-4">
                                <h6 class="mb-0">{{ number_format($avgEngagementRate, 2) }}%</h6>
                                <small class="text-muted">{{ __('Avg Rate') }}</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5>{{ __('Campaign Performance Summary') }}</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>{{ __('Date') }}</th>
                                    <th>{{ __('Impressions') }}</th>
                                    <th>{{ __('Clicks') }}</th>
                                    <th>{{ __('Reach') }}</th>
                                    <th>{{ __('Conversions') }}</th>
                                    <th>{{ __('Spend') }}</th>
                                    <th>{{ __('CTR') }}</th>
                                    <th>{{ __('CPC') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $groupedResults = $campaignResults->groupBy(function($item) {
                                        return $item->date->format('Y-m-d');
                                    });
                                @endphp
                                @forelse($groupedResults as $date => $results)
                                    <tr>
                                        <td>{{ \Carbon\Carbon::parse($date)->format('M d, Y') }}</td>
                                        <td>{{ number_format($results->sum('impressions')) }}</td>
                                        <td>{{ number_format($results->sum('clicks')) }}</td>
                                        <td>{{ number_format($results->sum('reach')) }}</td>
                                        <td>{{ number_format($results->sum('conversions')) }}</td>
                                        <td>${{ number_format($results->sum('spend'), 2) }}</td>
                                        <td>{{ number_format($results->avg('ctr'), 2) }}%</td>
                                        <td>${{ number_format($results->avg('cpc'), 4) }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="8" class="text-center py-4">
                                            <p class="text-muted">{{ __('No analytics data available for the selected period') }}</p>
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                            @if($groupedResults->isNotEmpty())
                                <tfoot>
                                    <tr class="fw-bold">
                                        <td>{{ __('Total') }}</td>
                                        <td>{{ number_format($campaignResults->sum('impressions')) }}</td>
                                        <td>{{ number_format($campaignResults->sum('clicks')) }}</td>
                                        <td>{{ number_format($campaignResults->sum('reach')) }}</td>
                                        <td>{{ number_format($campaignResults->sum('conversions')) }}</td>
                                        <td>${{ number_format($campaignResults->sum('spend'), 2) }}</td>
                                        <td>{{ number_format($campaignResults->avg('ctr'), 2) }}%</td>
                                        <td>${{ number_format($campaignResults->avg('cpc'), 4) }}</td>
                                    </tr>
                                </tfoot>
                            @endif
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5>{{ __('Account Insights') }}</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>{{ __('Date') }}</th>
                                    <th>{{ __('Account') }}</th>
                                    <th>{{ __('Followers') }}</th>
                                    <th>{{ __('Page Views') }}</th>
                                    <th>{{ __('Profile Visits') }}</th>
                                    <th>{{ __('Engagement') }}</th>
                                    <th>{{ __('Engagement Rate') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($insights as $insight)
                                    <tr>
                                        <td>{{ $insight->date->format('M d, Y') }}</td>
                                        <td>
                                            <i class="{{ $insight->account->platform_icon }}" style="color: {{ $insight->account->platform_color }};"></i>
                                            {{ $insight->account->account_name }}
                                        </td>
                                        <td>{{ number_format($insight->followers) }}</td>
                                        <td>{{ number_format($insight->page_views) }}</td>
                                        <td>{{ number_format($insight->profile_visits) }}</td>
                                        <td>{{ number_format($insight->total_engagement) }}</td>
                                        <td>{{ number_format($insight->engagement_rate, 2) }}%</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center py-4">
                                            <p class="text-muted">{{ __('No insights data available') }}</p>
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
