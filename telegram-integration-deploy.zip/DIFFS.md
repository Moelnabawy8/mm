# Telegram integration — manual patches for files that ALREADY exist on the server

> DO NOT overwrite these files with full copies. The server versions may contain
> changes that do not exist locally. Apply only the additions below, using the
> anchor lines to find the right place. After patching, run `php -l <file>` on each.

Conventions: "ANCHOR" = a line that already exists in your server copy (search for it).
"ADD" = the exact code to insert. Keep indentation identical to the surrounding code.

---

## 1. `routes/console.php` — append at the END of the file

ANCHOR: end of file (after the last `Schedule::...` line).

ADD:

```php
// Telegram task notifications ────────────────────────────────────
// Long-polling dispatcher: links chats via getUpdates (/start tokens) and drains
// the telegram_messages outbox. Every minute; the command itself bows out after
// ~50s (max-runtime) so ticks never overlap. Registered here — NOT in
// app/Console/Kernel.php, which is dead code on Laravel 11 (never loaded, so
// anything scheduled there silently dies). Verify with `php artisan schedule:list`.
//
// REQUIRES `php artisan schedule:run` every minute in the site user's crontab
// (crontab -u erpmy5243 -l). If schedule:run is not there, add a direct line
// instead, mirroring the whatsapp:dispatch cron entry.
Schedule::command('telegram:dispatch')->everyMinute()->withoutOverlapping();

// Due-date reminders for Telegram (today/tomorrow only — never overdue tasks).
Schedule::command('telegram:task-reminders')->dailyAt('08:00')->withoutOverlapping();
```

NOTE: `Schedule` facade must be imported. If the top of your server `routes/console.php`
does NOT contain `use Illuminate\Support\Facades\Schedule;`, add that line too.

---

## 2. `routes/web.php` — 10 routes inside the authenticated group

ANCHOR (primary): the line

```php
Route::get('whatsapp/task/{taskId}', [\App\Http\Controllers\WhatsAppController::class, 'taskTab'])->name('whatsapp.task.tab');
```

Insert the block below DIRECTLY AFTER it (same indentation as the WhatsApp lines).

ANCHOR (fallback, if the WhatsApp block is missing on the server): after the line

```php
Route::post('twilio-settings', [SystemController::class, 'saveTwilioSettings'])->name('twilio.setting');
```

— anywhere inside the `auth` middleware group is fine, but keep it next to the
other settings/notification routes.

ADD:

```php
// Telegram task notifications (Bot API, long-polling). No webhook anywhere:
// linking + delivery both run inside `telegram:dispatch` via getUpdates, so
// no public endpoint and no CSRF exception is needed — ever.
Route::post('telegram-settings', [\App\Http\Controllers\TelegramController::class, 'saveSettings'])->name('telegram.settings');
Route::post('telegram/connection', [\App\Http\Controllers\TelegramController::class, 'connection'])->name('telegram.connection');
Route::get('telegram/link', [\App\Http\Controllers\TelegramController::class, 'link'])->name('telegram.link');
Route::post('telegram/link/regenerate', [\App\Http\Controllers\TelegramController::class, 'regenerateLink'])->name('telegram.link.regenerate');
Route::post('telegram/link/unlink', [\App\Http\Controllers\TelegramController::class, 'unlinkOwn'])->name('telegram.link.unlink');
Route::get('telegram/recipients', [\App\Http\Controllers\TelegramController::class, 'recipients'])->name('telegram.recipients');
Route::post('telegram/recipients/{id}/unlink', [\App\Http\Controllers\TelegramController::class, 'unlinkRecipient'])->name('telegram.recipients.unlink');
Route::post('telegram/recipients/{id}/test', [\App\Http\Controllers\TelegramController::class, 'testSend'])->name('telegram.recipients.test');
Route::get('telegram/log', [\App\Http\Controllers\TelegramController::class, 'log'])->name('telegram.log');
Route::post('telegram/log/{id}/resend', [\App\Http\Controllers\TelegramController::class, 'resend'])->name('telegram.log.resend');
```

VERIFY: `php artisan route:list --name=telegram` must show 10 routes.

---

## 3. `app/Observers/ProjectTaskObserver.php`

### 3a. Imports — ADD 3 lines after `use App\Models\User;`:

```php
use App\Support\Telegram\TelegramConfig;
use App\Support\Telegram\TelegramGate;
use App\Support\Telegram\TelegramNotifier;
```

(place them before the `use App\Support\WhatsApp\...` lines, alphabetical order)

### 3b. HARD RULE comment — REPLACE

FIND:

```
 * HARD RULE: this class must never write to `project_tasks` or `task_comments`. It only
 * inserts into `whatsapp_messages`. That is what makes observer recursion structurally
```

REPLACE WITH:

```
 * HARD RULE: this class must never write to `project_tasks` or `task_comments`. It only
 * inserts into `whatsapp_messages` / `telegram_messages`. That is what makes observer
```

(leave the remaining lines of the comment untouched)

### 3c. `created()` — REPLACE the whole method

FIND (the current method body):

```php
    public function created(ProjectTask $task): void
    {
        if (WhatsAppGate::suppressed() || !WhatsAppConfig::enabled()) {
            return;
        }
        if (!WhatsAppConfig::eventEnabled('assign')) {
            return;
        }

        $ids = TaskNotifier::ids($task->assign_to);
        if (!$ids) {
            return;
        }

        WhatsAppGate::count(count($ids));
        app(TaskNotifier::class)->assigned($task, $ids, $this->actor());
    }
```

REPLACE WITH:

```php
    public function created(ProjectTask $task): void
    {
        if (!WhatsAppGate::suppressed() && WhatsAppConfig::enabled()
            && WhatsAppConfig::eventEnabled('assign')) {
            $ids = TaskNotifier::ids($task->assign_to);
            if ($ids) {
                WhatsAppGate::count(count($ids));
                app(TaskNotifier::class)->assigned($task, $ids, $this->actor());
            }
        }

        // Telegram task notifications — independent channel with its own gate and
        // config. Same entry point, separate everything else.
        if (!TelegramGate::suppressed() && TelegramConfig::enabled()
            && TelegramConfig::eventEnabled('assign')) {
            $ids = TelegramNotifier::ids($task->assign_to);
            if ($ids) {
                TelegramGate::count(count($ids));
                app(TelegramNotifier::class)->assigned($task, $ids, $this->actor());
            }
        }
    }
```

(WhatsApp behaviour is unchanged — identical conditions, only nested instead of
early-return, so the Telegram block still runs when WhatsApp is disabled.)

### 3d. `updated()` — REPLACE the whole method

FIND the current method (starts with `public function updated(ProjectTask $task): void`
and ends before the `private function actor()`), REPLACE WITH:

```php
    public function updated(ProjectTask $task): void
    {
        // getChanges() only lists columns that actually changed in this save, so the kanban
        // reorder loop (which touches `order` on every task in a column) and plain
        // updated_at touches never get past here.
        $changed = array_keys($task->getChanges());

        // `is_complete` is deliberately NOT in this list: taskOrderUpdate and the API both
        // set it together with stage_id in one save(), so keying on stage_id alone yields
        // exactly one event instead of two.
        if (!array_intersect($changed, ['assign_to', 'stage_id'])) {
            return;
        }

        $actor = $this->actor();

        if (!WhatsAppGate::suppressed() && WhatsAppConfig::enabled()) {
            if (in_array('assign_to', $changed, true) && WhatsAppConfig::eventEnabled('assign')) {
                $old   = TaskNotifier::ids($task->getOriginal('assign_to'));
                $new   = TaskNotifier::ids($task->assign_to);
                $added = array_values(array_diff($new, $old)); // only newly added people

                if ($added) {
                    WhatsAppGate::count(count($added));
                    app(TaskNotifier::class)->assigned($task, $added, $actor);
                }
            }

            if (in_array('stage_id', $changed, true) && WhatsAppConfig::eventEnabled('stage')) {
                // Don't tell people about something they just did themselves.
                $recipients = array_values(array_diff(
                    TaskNotifier::ids($task->assign_to),
                    array_filter([$actor?->id])
                ));

                if ($recipients) {
                    WhatsAppGate::count(count($recipients));
                    app(TaskNotifier::class)->stageChanged(
                        $task,
                        $recipients,
                        $task->getOriginal('stage_id') ? (int) $task->getOriginal('stage_id') : null,
                        $task->stage_id ? (int) $task->stage_id : null,
                        $actor
                    );
                }
            }
        }

        // Telegram task notifications — independent channel with its own gate and config.
        if (!TelegramGate::suppressed() && TelegramConfig::enabled()) {
            if (in_array('assign_to', $changed, true) && TelegramConfig::eventEnabled('assign')) {
                $old   = TelegramNotifier::ids($task->getOriginal('assign_to'));
                $new   = TelegramNotifier::ids($task->assign_to);
                $added = array_values(array_diff($new, $old)); // only newly added people

                if ($added) {
                    TelegramGate::count(count($added));
                    app(TelegramNotifier::class)->assigned($task, $added, $actor);
                }
            }

            if (in_array('stage_id', $changed, true) && TelegramConfig::eventEnabled('stage')) {
                // Don't tell people about something they just did themselves.
                $recipients = array_values(array_diff(
                    TelegramNotifier::ids($task->assign_to),
                    array_filter([$actor?->id])
                ));

                if ($recipients) {
                    TelegramGate::count(count($recipients));
                    app(TelegramNotifier::class)->stageChanged(
                        $task,
                        $recipients,
                        $task->getOriginal('stage_id') ? (int) $task->getOriginal('stage_id') : null,
                        $task->stage_id ? (int) $task->stage_id : null,
                        $actor
                    );
                }
            }
        }
    }
```

---

## 4. `app/Observers/TaskCommentObserver.php`

### 4a. Imports — ADD 3 lines after `use App\Models\User;`:

```php
use App\Support\Telegram\TelegramConfig;
use App\Support\Telegram\TelegramGate;
use App\Support\Telegram\TelegramNotifier;
```

### 4b. `created()` — REPLACE the whole method

FIND the current method (early-returns on `WhatsAppGate::suppressed()`,
`!WhatsAppConfig::enabled()`, `!eventEnabled('comment')`, then notifies), REPLACE WITH:

```php
    public function created(TaskComment $comment): void
    {
        $task = ProjectTask::find($comment->task_id);
        if (!$task) {
            return;
        }

        $actor = Auth::check() ? Auth::user() : $this->authorFrom($comment);

        if (!WhatsAppGate::suppressed() && WhatsAppConfig::enabled()
            && WhatsAppConfig::eventEnabled('comment')) {
            $recipients = array_values(array_diff(
                TaskNotifier::ids($task->assign_to),
                array_filter([$actor?->id])
            ));

            if ($recipients) {
                WhatsAppGate::count(count($recipients));

                app(TaskNotifier::class)->commented(
                    $task,
                    $recipients,
                    (int) $comment->id,
                    (string) $comment->comment,
                    $actor
                );
            }
        }

        // Telegram task notifications — independent channel with its own gate and config.
        if (!TelegramGate::suppressed() && TelegramConfig::enabled()
            && TelegramConfig::eventEnabled('comment')) {
            $recipients = array_values(array_diff(
                TelegramNotifier::ids($task->assign_to),
                array_filter([$actor?->id])
            ));

            if ($recipients) {
                TelegramGate::count(count($recipients));

                app(TelegramNotifier::class)->commented(
                    $task,
                    $recipients,
                    (int) $comment->id,
                    (string) $comment->comment,
                    $actor
                );
            }
        }
    }
```

(leave `authorFrom()` untouched)

---

## 5. `app/Http/Controllers/ApiController.php` — 1 line in `duplicateProject()`

ANCHOR: inside `duplicateProject()`, the line

```php
        \App\Support\WhatsApp\WhatsAppGate::suppressForRequest();
```

ADD directly after it:

```php
        \App\Support\Telegram\TelegramGate::suppressForRequest();
```

WHY: the clone loops re-save every task and comment; without this, duplicating a
project would enqueue one Telegram message per copied row.

---

## 6. `resources/views/settings/company.blade.php` — 2 inserts

### 6a. Sidebar link — ANCHOR:

```blade
                            @can('manage whatsapp notification')
                                <a href="#whatsapp-settings"
                                    class="list-group-item list-group-item-action border-0">{{ __('WhatsApp Task Notifications') }}
                                    <div class="float-end"><i class="ti ti-chevron-right"></i></div>
                                </a>
                            @endcan
```

ADD directly after it:

```blade
                            @can('manage telegram notification')
                                <a href="#telegram-settings"
                                    class="list-group-item list-group-item-action border-0">{{ __('Telegram Task Notifications') }}
                                    <div class="float-end"><i class="ti ti-chevron-right"></i></div>
                                </a>
                            @endcan
```

### 6b. Settings card — ANCHOR:

```blade
                    <!--WhatsApp Task Notifications-->
                    @can('manage whatsapp notification')
                        @include('whatsapp.partials.settings')
                    @endcan
```

ADD directly after it:

```blade
                    <!--Telegram Task Notifications-->
                    @can('manage telegram notification')
                        @include('telegram.partials.settings')
                    @endcan
```

---

## 7. `resources/views/partials/admin/menu.blade.php` — 1 insert

ANCHOR (primary): the WhatsApp log block

```blade
                                @if (Gate::check('view whatsapp log') && Route::has('whatsapp.log'))
                                    <li
                                        class="dash-item {{ Request::segment(1) == 'whatsapp' && Request::segment(2) == 'log' ? ' active' : '' }}">
                                        <a href="{{ route('whatsapp.log') }}"
                                            class="dash-link">{{ __('WhatsApp Delivery Log') }}</a>
                                    </li>
                                @endif
```

ADD directly after it:

```blade
                                @if (Route::has('telegram.link'))
                                    <li
                                        class="dash-item {{ Request::segment(1) == 'telegram' && Request::segment(2) == 'link' ? ' active' : '' }}">
                                        <a href="{{ route('telegram.link') }}"
                                            class="dash-link">{{ __('Link Telegram Account') }}</a>
                                    </li>
                                @endif
                                @if (Gate::check('view telegram log') && Route::has('telegram.log'))
                                    <li
                                        class="dash-item {{ Request::segment(1) == 'telegram' && Request::segment(2) == 'log' ? ' active' : '' }}">
                                        <a href="{{ route('telegram.log') }}"
                                            class="dash-link">{{ __('Telegram Delivery Log') }}</a>
                                    </li>
                                @endif
```

FALLBACK: if the WhatsApp block is missing on the server, insert before the
`@if (Gate::check('manage company plan'))` line instead.

---

## Post-patch verification (on the server)

```bash
php -l routes/console.php && php -l routes/web.php \
  && php -l app/Observers/ProjectTaskObserver.php \
  && php -l app/Observers/TaskCommentObserver.php \
  && php -l app/Http/Controllers/ApiController.php
php artisan route:list --name=telegram        # must show 10 routes
php artisan schedule:list                     # must show telegram:dispatch every minute
```
