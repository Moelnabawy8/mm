<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Deal;
use App\Models\Lead;
use App\Models\Stage;
use App\Models\Pipeline;
use App\Models\ProductService;
use App\Models\DealAttachment;
use App\Models\CustomField;
use App\Traits\ApiResponser;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;

class DealApiController extends Controller
{
    use ApiResponser;

    public function getDeals()
    {
        $deals = Deal::where('created_by', Auth::user()->creatorId())->with(['stage', 'lead', 'pipeline'])->get();
        return $this->success(['deals' => $deals], 'Deals retrieved.');
    }

    public function createDeal(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'lead_id' => 'required|exists:leads,id',
                'stage_id' => 'required|exists:stages,id',
            ]
        );

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 422);
        }

        $lead = Lead::find($request->lead_id);
        $stage = Stage::find($request->stage_id);

        $deal = new Deal();
        $deal->name = $request->name;
        $deal->lead_id = $request->lead_id;
        if ($request->products) {
            $deal->products = implode(',', array_filter($request->products));
        }
        $deal->created_by = Auth::user()->creatorId();
        $deal->stage_id = $request->stage_id;
        $deal->status = $stage ? $stage->name : null;
        $deal->pipeline_id = $lead->pipeline_id ?? 0;
        $deal->notes = $request->notes;
        $deal->datetime = $request->datetime;
        $deal->save();

        if ($request->customField) {
            CustomField::saveData($deal, $request->customField);
        }

        return $this->success(['deal' => $deal], 'Deal created successfully.');
    }

    public function getDeal($id)
    {
        $deal = Deal::where('id', $id)->where('created_by', Auth::user()->creatorId())->with(['stage', 'lead', 'pipeline', 'attachments'])->first();
        if (!$deal) {
            return $this->error('Deal not found.', 404);
        }

        // Get Products
        $products = [];
        if ($deal->products) {
            $productIds = explode(',', $deal->products);
            $products = ProductService::whereIn('id', $productIds)->get();
        }
        $deal->product_details = $products;

        // Get Custom Fields
        $deal->custom_fields = CustomField::getData($deal, 'deal');

        return $this->success(['deal' => $deal], 'Deal details.');
    }

    public function updateDeal(Request $request, $id)
    {
        $deal = Deal::where('id', $id)->where('created_by', Auth::user()->creatorId())->first();
        if (!$deal) {
            return $this->error('Deal not found.', 404);
        }

        $validator = Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'stage_id' => 'required|exists:stages,id',
            ]
        );

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 422);
        }

        $deal->name = $request->name;
        if ($request->has('lead_id')) {
            $deal->lead_id = $request->lead_id;
        }

        if ($request->products) {
            $deal->products = implode(',', array_filter($request->products));
        }

        $deal->stage_id = $request->stage_id;
        $stage = Stage::find($request->stage_id);
        $deal->status = $stage ? $stage->name : null;

        if ($request->has('notes')) {
            $deal->notes = $request->notes;
        }
        if ($request->has('datetime')) {
            $deal->datetime = $request->datetime;
        }

        $deal->save();

        if ($request->customField) {
            CustomField::saveData($deal, $request->customField);
        }

        return $this->success(['deal' => $deal], 'Deal updated successfully.');
    }

    public function deleteDeal($id)
    {
        $deal = Deal::where('id', $id)->where('created_by', Auth::user()->creatorId())->first();
        if (!$deal) {
            return $this->error('Deal not found.', 404);
        }
        $deal->delete();
        return $this->success([], 'Deal deleted successfully.');
    }

    public function addDealProduct(Request $request, $id)
    {
        $deal = Deal::where('id', $id)->where('created_by', Auth::user()->creatorId())->first();
        if (!$deal) {
            return $this->error('Deal not found.', 404);
        }

        $validator = Validator::make(
            $request->all(),
            [
                'product_id' => 'required|exists:product_services,id',
            ]
        );

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 422);
        }

        $old_products = $deal->products ? explode(',', $deal->products) : [];
        if (!in_array($request->product_id, $old_products)) {
            $old_products[] = $request->product_id;
            $deal->products = implode(',', $old_products);
            $deal->save();
        }

        return $this->success(['deal' => $deal], 'Product added to deal.');
    }

    public function getDealAttachments($id)
    {
        $deal = Deal::where('id', $id)->where('created_by', Auth::user()->creatorId())->first();
        if (!$deal) {
            return $this->error('Deal not found.', 404);
        }
        $attachments = DealAttachment::where('deal_id', $id)->get();
        return $this->success(['attachments' => $attachments], 'Deal attachments.');
    }

    public function uploadDealAttachment(Request $request, $id)
    {
        $deal = Deal::where('id', $id)->where('created_by', Auth::user()->creatorId())->first();
        if (!$deal) {
            return $this->error('Deal not found.', 404);
        }

        $validator = Validator::make(
            $request->all(),
            [
                'file' => 'required|file|max:10240',
            ]
        );

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 422);
        }

        $file = $request->file('file');
        $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
        $storagePath = 'deal_attachments/' . $id;
        $file->storeAs($storagePath, $fileName, 'public');

        $attachment = DealAttachment::create([
            'deal_id' => $id,
            'file_name' => $file->getClientOriginalName(),
            'file_path' => $storagePath . '/' . $fileName,
            'file_type' => $file->getClientMimeType(), // Simplified
            'mime_type' => $file->getClientMimeType(),
            'file_size' => $file->getSize(),
            'uploaded_by' => Auth::id(),
        ]);

        return $this->success(['attachment' => $attachment], 'Attachment uploaded successfully.');
    }

    public function getPipelines()
    {
        $pipelines = Pipeline::where('created_by', Auth::user()->creatorId())->get();
        return $this->success(['pipelines' => $pipelines], 'Pipelines retrieved.');
    }

    public function getDealStages()
    {
        $stages = Stage::where('created_by', Auth::user()->creatorId())->orderBy('order')->get();
        return $this->success(['stages' => $stages], 'Stages retrieved.');
    }
}
