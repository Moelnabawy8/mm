<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Lead;
use App\Traits\ApiResponser;
use Illuminate\Support\Facades\Auth;

class LeadApiController extends Controller
{
    use ApiResponser;

    public function getLeads()
    {
        $leads = Lead::where('created_by', Auth::user()->creatorId())->get();
        return $this->success(['leads' => $leads], 'Leads retrieved.');
    }

    public function createLead(Request $request) { return $this->success([], 'Use web interface for complex lead creation or implement full validation here.'); }

    public function getLead($id)
    {
        $lead = Lead::find($id);
        if (!$lead) return $this->error('Lead not found.', 404);
        return $this->success(['lead' => $lead], 'Lead detail retrieved.');
    }

    public function updateLead(Request $request, $id)
    {
        $lead = Lead::find($id);
        if (!$lead) return $this->error('Lead not found.', 404);
        $lead->update($request->all());
        return $this->success(['lead' => $lead], 'Lead updated successfully.');
    }

    public function deleteLead($id)
    {
        $lead = Lead::find($id);
        if (!$lead) return $this->error('Lead not found.', 404);
        $lead->delete();
        return $this->success([], 'Lead deleted successfully.');
    }
    
    public function convertLead($id) { return $this->error('Lead conversion not supported via API yet.', 501); }

    public function getLeadStages()
    {
        $stages = \App\Models\LeadStage::where('created_by', Auth::user()->creatorId())->get();
        return $this->success(['stages' => $stages], 'Lead stages retrieved.');
    }

    public function getLeadSources()
    {
        $sources = \App\Models\Source::where('created_by', Auth::user()->creatorId())->get();
        return $this->success(['sources' => $sources], 'Lead sources retrieved.');
    }
}
