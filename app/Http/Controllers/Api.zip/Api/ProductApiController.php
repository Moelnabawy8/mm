<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProductService;
use App\Models\ProductServiceCategory;
use App\Models\ProductServiceUnit;
use App\Models\Tax;
use App\Models\CustomField;
use App\Models\Utility;
use App\Traits\ApiResponser;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class ProductApiController extends Controller
{
    use ApiResponser;

    public function getProducts(Request $request)
    {
        $query = ProductService::where('created_by', Auth::user()->creatorId());

        if ($request->category_id) {
            $query->where('category_id', $request->category_id);
        }

        $products = $query->with(['category', 'unit', 'tax'])->get();
        return $this->success(['products' => $products], 'Products retrieved.');
    }

    public function createProduct(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'sku' => [
                    'required',
                    Rule::unique('product_services')->where(function ($query) {
                        return $query->where('created_by', Auth::user()->creatorId());
                    })
                ],
                'sale_price' => 'required|numeric',
                'purchase_price' => 'required|numeric',
                'category_id' => 'required',
                'unit_id' => 'required',
                'type' => 'required',
            ]
        );

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 422);
        }

        $productService                      = new ProductService();
        $productService->name                = $request->name;
        $productService->description         = $request->description;
        $productService->sku                 = $request->sku;
        $productService->sale_price          = $request->sale_price;
        $productService->purchase_price      = $request->purchase_price;
        $productService->tax_id              = !empty($request->tax_id) ? implode(',', $request->tax_id) : '';
        $productService->unit_id             = $request->unit_id;
        $productService->quantity            = !empty($request->quantity) ? $request->quantity : 0;
        $productService->type                = $request->type;
        $productService->sale_chartaccount_id    = $request->sale_chartaccount_id;
        $productService->expense_chartaccount_id = $request->expense_chartaccount_id;
        $productService->category_id         = $request->category_id;
        $productService->created_by          = Auth::user()->creatorId();

        if ($request->hasFile('pro_image')) {
            $fileName = time() . "_" . $request->file('pro_image')->getClientOriginalName();
            $path = Utility::upload_file($request, 'pro_image', $fileName, 'uploads/pro_image', []);
            if ($path['flag'] == 1) {
                $productService->pro_image = $fileName;
            }
        }

        $productService->save();

        if ($request->customField) {
            CustomField::saveData($productService, $request->customField);
        }

        return $this->success(['product' => $productService], 'Product created successfully.');
    }

    public function getProduct($id)
    {
        $product = ProductService::where('id', $id)->where('created_by', Auth::user()->creatorId())->with(['category', 'unit'])->first();
        if (!$product) {
            return $this->error('Product not found.', 404);
        }
        $product->custom_fields = CustomField::getData($product, 'product');
        return $this->success(['product' => $product], 'Product details.');
    }

    public function updateProduct(Request $request, $id)
    {
        $productService = ProductService::where('id', $id)->where('created_by', Auth::user()->creatorId())->first();
        if (!$productService) {
            return $this->error('Product not found.', 404);
        }

        $validator = Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'sku' => [
                    'required',
                    Rule::unique('product_services')->where(function ($query) {
                        return $query->where('created_by', Auth::user()->creatorId());
                    })->ignore($productService->id)
                ],
                'sale_price' => 'required|numeric',
                'purchase_price' => 'required|numeric',
                'category_id' => 'required',
                'unit_id' => 'required',
                'type' => 'required',
            ]
        );

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 422);
        }

        $productService->name                = $request->name;
        $productService->description         = $request->description;
        $productService->sku                 = $request->sku;
        $productService->sale_price          = $request->sale_price;
        $productService->purchase_price      = $request->purchase_price;
        $productService->tax_id              = !empty($request->tax_id) ? implode(',', $request->tax_id) : '';
        $productService->unit_id             = $request->unit_id;
        $productService->quantity            = !empty($request->quantity) ? $request->quantity : 0;
        $productService->type                = $request->type;
        $productService->sale_chartaccount_id    = $request->sale_chartaccount_id;
        $productService->expense_chartaccount_id = $request->expense_chartaccount_id;
        $productService->category_id         = $request->category_id;

        if ($request->hasFile('pro_image')) {
            $fileName = time() . "_" . $request->file('pro_image')->getClientOriginalName();
            $path = Utility::upload_file($request, 'pro_image', $fileName, 'uploads/pro_image', []);
            if ($path['flag'] == 1) {
                $productService->pro_image = $fileName;
            }
        }

        $productService->save();

        if ($request->customField) {
            CustomField::saveData($productService, $request->customField);
        }

        return $this->success(['product' => $productService], 'Product updated successfully.');
    }

    public function deleteProduct($id)
    {
        $productService = ProductService::where('id', $id)->where('created_by', Auth::user()->creatorId())->first();
        if (!$productService) {
            return $this->error('Product not found.', 404);
        }
        $productService->delete();
        return $this->success([], 'Product deleted successfully.');
    }

    public function getProductCategories()
    {
        $categories = ProductServiceCategory::where('created_by', Auth::user()->creatorId())->where('type', 'product & service')->get();
        return $this->success(['categories' => $categories], 'Categories retrieved.');
    }

    public function getProductUnits()
    {
        $units = ProductServiceUnit::where('created_by', Auth::user()->creatorId())->get();
        return $this->success(['units' => $units], 'Units retrieved.');
    }

    public function getProductStock($id)
    {
        // This seems to refer to stock history or details, simplified to product details with quantity for now
        // Or StockReport if available.
        // Based on stub name, let's return quantity and maybe latest stock moves if needed.
        $product = ProductService::where('id', $id)->where('created_by', Auth::user()->creatorId())->first();
        if (!$product) {
            return $this->error('Product not found.', 404);
        }
        return $this->success(['stock' => $product->quantity], 'Product stock.');
    }

    public function importProducts(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'file' => 'required|file|mimes:csv,txt',
            'column_mapping' => 'required|array',
            'column_mapping.*' => 'required|string|in:name,sku,category,unit,price,sale_price,quantity,description',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 422);
        }

        if (!$request->hasFile('file')) {
            return $this->error('No file provided.', 400);
        }

        $file = $request->file('file');
        $filePath = $file->getRealPath();
        $file_extension = $file->getClientOriginalExtension();

        if ($file_extension !== 'csv') {
            return $this->error('Only CSV files are supported.', 400);
        }

        try {
            $file_data = [];
            $header = null;

            if (($handle = fopen($filePath, 'r')) !== FALSE) {
                while (($row = fgetcsv($handle, 1000, ',')) !== FALSE) {
                    if (!$header) {
                        $header = $row;
                    } else {
                        $file_data[] = $row;
                    }
                }
                fclose($handle);
            }

            $columnMapping = $request->column_mapping;
            $results = [];
            $errors = [];
            $successCount = 0;
            $errorCount = 0;

            foreach ($file_data as $key => $row) {
                try {
                    // Validate required fields
                    $nameColumn = array_search('name', $columnMapping);
                    $skuColumn = array_search('sku', $columnMapping);

                    if ($nameColumn === false || empty($row[$nameColumn])) {
                        $errors[] = "Row " . ($key + 2) . ": Product name is required.";
                        $errorCount++;
                        continue;
                    }

                    // Check if product with this SKU already exists
                    if ($skuColumn !== false && !empty($row[$skuColumn])) {
                        $existingProduct = \App\Models\ProductService::where('created_by', Auth::user()->creatorId())
                            ->where('sku', 'like', $row[$skuColumn])
                            ->first();

                        if ($existingProduct) {
                            $errors[] = "Row " . ($key + 2) . ": Product with SKU '{$row[$skuColumn]}' already exists.";
                            $errorCount++;
                            continue;
                        }
                    }

                    // Validate numeric fields
                    $priceColumn = array_search('price', $columnMapping);
                    $salePriceColumn = array_search('sale_price', $columnMapping);
                    $quantityColumn = array_search('quantity', $columnMapping);

                    if ($priceColumn !== false && !empty($row[$priceColumn]) && !is_numeric($row[$priceColumn])) {
                        $errors[] = "Row " . ($key + 2) . ": Price must be a valid number.";
                        $errorCount++;
                        continue;
                    }

                    if ($salePriceColumn !== false && !empty($row[$salePriceColumn]) && !is_numeric($row[$salePriceColumn])) {
                        $errors[] = "Row " . ($key + 2) . ": Sale price must be a valid number.";
                        $errorCount++;
                        continue;
                    }

                    if ($quantityColumn !== false && !empty($row[$quantityColumn]) && !is_numeric($row[$quantityColumn])) {
                        $errors[] = "Row " . ($key + 2) . ": Quantity must be a valid number.";
                        $errorCount++;
                        continue;
                    }

                    // Prepare product data
                    $productData = [
                        'name' => $row[$nameColumn],
                        'sku' => $skuColumn !== false && !empty($row[$skuColumn]) ? $row[$skuColumn] : $this->generateSKU(),
                        'type' => 'product',
                        'created_by' => Auth::user()->creatorId(),
                    ];

                    // Add optional fields
                    $optionalFields = [
                        'category' => 'category',
                        'unit' => 'unit',
                        'price' => 'price',
                        'sale_price' => 'sale_price',
                        'quantity' => 'quantity',
                        'description' => 'description',
                    ];

                    foreach ($optionalFields as $field => $column) {
                        $columnIndex = array_search($column, $columnMapping);
                        if ($columnIndex !== false && !empty($row[$columnIndex])) {
                            $productData[$field] = $field === 'price' || $field === 'sale_price' || $field === 'quantity' ? floatval($row[$columnIndex]) : $row[$columnIndex];
                        }
                    }

                    // Create product
                    $product = \App\Models\ProductService::create($productData);

                    // Add initial stock record if quantity provided
                    if ($quantityColumn !== false && !empty($row[$quantityColumn]) && floatval($row[$quantityColumn]) > 0) {
                        \App\Models\Utility::addProductStock(
                            $product->id,
                            floatval($row[$quantityColumn]),
                            'import',
                            'Initial stock added during import',
                            0
                        );
                    }

                    $results[] = [
                        'row' => $key + 2,
                        'name' => $product->name,
                        'sku' => $product->sku,
                        'quantity' => $product->quantity,
                        'status' => 'success'
                    ];
                    $successCount++;
                } catch (\Exception $e) {
                    $errors[] = "Row " . ($key + 2) . ": " . $e->getMessage();
                    $errorCount++;
                }
            }

            return $this->success([
                'results' => $results,
                'errors' => $errors,
                'summary' => [
                    'total_rows' => count($file_data),
                    'success_count' => $successCount,
                    'error_count' => $errorCount
                ]
            ], 'Product import completed.');
        } catch (\Exception $e) {
            return $this->error('Error processing file: ' . $e->getMessage(), 500);
        }
    }

    public function exportProducts()
    {
        try {
            $products = \App\Models\ProductService::where('created_by', Auth::user()->creatorId())
                ->where('type', 'product')
                ->orderBy('created_at', 'desc')
                ->get();

            $csvData = [];
            $csvData[] = [
                'Name',
                'SKU',
                'Category',
                'Unit',
                'Price',
                'Sale Price',
                'Quantity',
                'Description',
                'Created At'
            ];

            foreach ($products as $product) {
                $csvData[] = [
                    $product->name,
                    $product->sku,
                    $product->category,
                    $product->unit,
                    $product->price,
                    $product->sale_price,
                    $product->quantity,
                    $product->description,
                    $product->created_at->format('Y-m-d H:i:s')
                ];
            }

            $filename = 'products_' . date('Y-m-d_H-i-s') . '.csv';

            $headers = [
                'Content-Type' => 'text/csv',
                'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            ];

            $callback = function () use ($csvData) {
                $file = fopen('php://output', 'w');
                foreach ($csvData as $row) {
                    fputcsv($file, $row);
                }
                fclose($file);
            };

            return response()->stream($callback, 200, $headers);
        } catch (\Exception $e) {
            return $this->error('Error exporting products: ' . $e->getMessage(), 500);
        }
    }

    private function generateSKU()
    {
        $lastProduct = \App\Models\ProductService::where('type', 'product')->orderBy('id', 'desc')->first();
        $lastNumber = $lastProduct ? intval(substr($lastProduct->sku, -4)) : 0;
        $newNumber = str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);
        return 'PRD' . date('Y') . $newNumber;
    }
}
