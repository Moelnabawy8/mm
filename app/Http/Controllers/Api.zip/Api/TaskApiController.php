<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProjectTask;
use App\Models\Project;
use App\Models\ActivityLog;
use App\Models\User;
use App\Models\Utility;
use App\Traits\ApiResponser;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class TaskApiController extends Controller
{
    use ApiResponser;

    public function getTasks()
    {
        $tasks = ProjectTask::where('created_by', Auth::user()->creatorId())->get();
        return $this->success(['tasks' => $tasks], 'Tasks retrieved.');
    }

    public function createProjectTask(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'project_id' => 'required|integer|exists:projects,id',
            'name' => 'required',
            'estimated_hrs' => 'required',
            'priority' => 'required',
            'stage_id' => 'required',
            'start_date' => 'required',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 401);
        }

        $usr = Auth::user();
        $project = Project::find($request->project_id);
        $post = $request->all();
        $post['created_by'] = $usr->creatorId();
        $post['start_date'] = date("Y-m-d H:i:s", strtotime($request->start_date));
        $post['end_date'] = isset($request->end_date) ? date("Y-m-d H:i:s", strtotime($request->end_date)) : null;

        $task = ProjectTask::create($post);

        return $this->success(['task' => $task], 'Task added successfully.');
    }

    public function getProjectTask($id)
    {
        $task = ProjectTask::find($id);
        if (!$task) return $this->error('Task not found', 404);
        return $this->success(['task' => $task], 'Task retrieved.');
    }

    public function updateProjectTask(Request $request, $id)
    {
        $task = ProjectTask::find($id);
        if (!$task) return $this->error('Task not found', 404);
        $task->update($request->all());
        return $this->success(['task' => $task], 'Task updated.');
    }

    public function deleteProjectTask($id)
    {
        $task = ProjectTask::find($id);
        if (!$task) return $this->error('Task not found', 404);
        $task->delete();
        return $this->success([], 'Task deleted.');
    }

    public function completeTask($id)
    {
        $task = ProjectTask::find($id);
        if (!$task) return $this->error('Task not found.', 404);

        $task->is_complete = 1;
        $task->marked_at = date('Y-m-d');
        $task->save();

        return $this->success(['task' => $task], 'Task completed successfully.');
    }

    public function addTaskComment(Request $request, $id)
    {
        $validator = Validator::make($request->all(), ['comment' => 'required']);
        if ($validator->fails()) return $this->error($validator->errors()->first(), 401);

        $task = ProjectTask::find($id);
        if (!$task) return $this->error('Task not found.', 404);

        $comment = new \App\Models\TaskComment();
        $comment->comment = $request->comment;
        $comment->task_id = $task->id;
        $comment->user_id = Auth::user()->id;
        $comment->user_type = Auth::user()->type;
        $comment->created_by = Auth::user()->creatorId();
        $comment->save();

        return $this->success(['comment' => $comment], 'Comment added successfully.');
    }

    public function getTaskComments($id)
    {
        $comments = \App\Models\TaskComment::with('user')->where('task_id', $id)->get();
        return $this->success(['comments' => $comments], 'Task comments retrieved.');
    }

    public function uploadTaskFile(Request $request, $id)
    {
        $validator = Validator::make($request->all(), ['file' => 'required|file']);
        if ($validator->fails()) return $this->error($validator->errors()->first(), 401);

        $task = ProjectTask::find($id);
        if (!$task) return $this->error('Task not found.', 404);

        $file = $request->file('file');
        $filenameWithExt = $file->getClientOriginalName();
        $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
        $extension = $file->getClientOriginalExtension();
        $fileNameToStore = $filename . '_' . time() . '.' . $extension;
        $dir = storage_path('uploads/tasks');
        if (!file_exists($dir)) mkdir($dir, 0777, true);
        $file->storeAs('uploads/tasks', $fileNameToStore);

        $taskFile = new \App\Models\TaskFile();
        $taskFile->task_id = $task->id;
        $taskFile->file = $fileNameToStore;
        $taskFile->name = $filename;
        $taskFile->extension = $extension;
        $taskFile->file_size = round($file->getSize() / 1024 / 1024, 2) . ' MB';
        $taskFile->user_type = Auth::user()->type;
        $taskFile->created_by = Auth::user()->creatorId();
        $taskFile->save();

        return $this->success(['file' => $taskFile], 'File uploaded successfully.');
    }

    public function getTaskFiles($id)
    {
        $files = \App\Models\TaskFile::where('task_id', $id)->get();
        return $this->success(['files' => $files], 'Task files retrieved.');
    }

    public function addTaskChecklist(Request $request, $id)
    {
        $validator = Validator::make($request->all(), ['name' => 'required']);
        if ($validator->fails()) return $this->error($validator->errors()->first(), 401);

        $checklist = new \App\Models\TaskChecklist();
        $checklist->name = $request->name;
        $checklist->task_id = $id;
        $checklist->user_type = Auth::user()->type;
        $checklist->created_by = Auth::user()->creatorId();
        $checklist->status = 0;
        $checklist->save();

        return $this->success(['checklist' => $checklist], 'Checklist added successfully.');
    }

    public function getTaskTimeTracker($id)
    {
        $trackers = \App\Models\TimeTracker::where('task_id', $id)->get();
        return $this->success(['trackers' => $trackers], 'Time trackers retrieved.');
    }

    public function startTimeTracker($id)
    {
        $task = ProjectTask::find($id);
        if (!$task) return $this->error('Task not found.', 404);

        $tracker = new \App\Models\TimeTracker();
        $tracker->project_id = $task->project_id;
        $tracker->task_id = $id;
        $tracker->name = $task->name;
        $tracker->user_id = Auth::user()->id;
        $tracker->created_by = Auth::user()->creatorId();
        $tracker->start_time = date('Y-m-d H:i:s');
        $tracker->save();

        return $this->success(['tracker' => $tracker], 'Time tracking started.');
    }

    public function stopTimeTracker($id)
    {
        $tracker = \App\Models\TimeTracker::where('task_id', $id)
            ->where('user_id', Auth::user()->id)
            ->whereNull('end_time')
            ->first();

        if (!$tracker) return $this->error('No active tracker found for this task.', 404);

        $tracker->end_time = date('Y-m-d H:i:s');
        $tracker->total_time = \App\Models\Utility::diffance_to_time($tracker->start_time, $tracker->end_time); // Assuming Utility helper exists
        $tracker->save();

        return $this->success(['tracker' => $tracker], 'Time tracking stopped.');
    }
}
