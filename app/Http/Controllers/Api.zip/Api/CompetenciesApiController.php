<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Competencies; 
use App\Traits\ApiResponser;
use Illuminate\Support\Facades\Auth;

class CompetenciesApiController extends Controller
{
    use ApiResponser;

    public function getCompetencies()
    {
        $competencies = Competencies::where('created_by', Auth::user()->creatorId())->get();
        return $this->success(['competencies' => $competencies], 'Competencies retrieved.');
    }
}
