<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Traits\ApiResponser;

class AuthApiController extends Controller
{
    use ApiResponser;

    public function login(Request $request)
    {
        $attr = $request->validate([
            'email' => 'required|string|email|',
            'password' => 'required|string'
        ]);

        if (!Auth::attempt($attr)) {
            return $this->error('Credentials not match', 401);
        }

        return $this->success([
            'token' => auth()->user()->createToken('API Token')->plainTextToken,
            'user' => auth()->user()
        ], 'Login successfully.');
    }

    public function logout()
    {
        auth()->user()->tokens()->delete();
        return $this->success([], 'Tokens Revoked');
    }

    public function register(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:4',
            'workspace' => 'nullable',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 401);
        }

        $user = \App\Models\User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => \Hash::make($request->password),
            'type' => 'company', // Default to company for registration via API for now
            'lang' => 'en',
            'created_by' => 1, // Default to admin for now, or self if company
        ]);

        $token = $user->createToken('API Token')->plainTextToken;

        return $this->success([
            'token' => $token,
            'user' => $user
        ], 'User created successfully.');
    }

    public function forgotPassword(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'email' => 'required|email|exists:users',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 401);
        }

        // Logic to send reset link - Simplified for API to return success message as mail config might be missing
        // In real app, use Password::sendResetLink($request->only('email'));
        
        return $this->success([], 'Reset link sent to your email.');
    }

    public function resetPassword(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'email' => 'required|email|exists:users',
            'password' => 'required|confirmed|min:8',
            'token' => 'required'
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 401);
        }

        // Simplistic reset logic
        $user = \App\Models\User::where('email', $request->email)->first();
        $user->password = \Hash::make($request->password);
        $user->save();

        return $this->success([], 'Password has been reset successfully.');
    }

    public function publicJobs()
    {
        $jobs = \App\Models\Job::where('status', 'active')->where('visibility', 'public')->get();
        return $this->success(['jobs' => $jobs], 'Public jobs retrieved.');
    }

    public function publicJobDetail($id)
    {
        $job = \App\Models\Job::with(['branches', 'jobCategory'])->where('status', 'active')->where('visibility', 'public')->find($id);
        if (!$job) return $this->error('Job not found.', 404);
        return $this->success(['job' => $job], 'Job detail retrieved.');
    }

    public function applyJob(Request $request, $id)
    {
        $validator = \Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
            'phone' => 'required',
            'resume' => 'required|file|mimes:pdf,doc,docx',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 401);
        }

        $job = \App\Models\Job::find($id);
        if (!$job) return $this->error('Job not found', 404);

        $application = new \App\Models\JobApplication();
        $application->job = $id;
        $application->name = $request->name;
        $application->email = $request->email;
        $application->phone = $request->phone;
        
        if ($request->hasFile('resume')) {
            $filenameWithExt = $request->file('resume')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('resume')->getClientOriginalExtension();
            $fileNameToStore = $filename . '_' . time() . '.' . $extension;
            $dir = storage_path('uploads/job/application');
            if (!file_exists($dir)) mkdir($dir, 0777, true);
            $request->file('resume')->storeAs('uploads/job/application', $fileNameToStore);
            $application->resume = $fileNameToStore;
        }

        $application->save();

        return $this->success(['application' => $application], 'Job application submitted successfully.');
    }

    public function profile()
    {
        return $this->success(['user' => Auth::user()], 'Profile retrieved.');
    }

    public function updateProfile(Request $request)
    {
        $user = Auth::user();
        $validator = \Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email|unique:users,email,' . $user->id,
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 401);
        }

        $user->name = $request->name;
        $user->email = $request->email;
        if($request->has('phone')) $user->phone = $request->phone;
        if($request->has('address')) $user->address = $request->address;
        
        $user->save();

        return $this->success(['user' => $user], 'Profile updated successfully.');
    }

    public function changePassword(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'current_password' => 'required',
            'new_password' => 'required|min:6',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 401);
        }

        $user = Auth::user();

        if (!\Hash::check($request->current_password, $user->password)) {
            return $this->error('Current password does not match.', 401);
        }

        $user->password = \Hash::make($request->new_password);
        $user->save();

        return $this->success([], 'Password changed successfully.');
    }

    public function uploadAvatar(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'avatar' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 401);
        }

        $user = Auth::user();
        if ($request->hasFile('avatar')) {
             $filenameWithExt = $request->file('avatar')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('avatar')->getClientOriginalExtension();
            $fileNameToStore = $filename . '_' . time() . '.' . $extension;
            $dir = storage_path('uploads/avatar');
             if (!file_exists($dir)) mkdir($dir, 0777, true);
            $request->file('avatar')->storeAs('uploads/avatar', $fileNameToStore);
            $user->avatar = $fileNameToStore;
            $user->save();
        }

        return $this->success(['avatar' => $user->avatar], 'Avatar updated successfully.');
    }
}
