<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AttendanceEmployee;
use App\Models\Employee;
use App\Models\Branch;
use App\Models\Department;
use App\Models\Utility;
use App\Models\IpRestrict;
use App\Traits\ApiResponser;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class AttendanceApiController extends Controller
{
    use ApiResponser;

    public function getAttendance(Request $request)
    {
        $user = Auth::user();
        
        if ($user->type == 'Employee') {
            $emp = Employee::where('user_id', $user->id)->first();
            $attendance = AttendanceEmployee::where('employee_id', $emp->id)
                ->with(['employee'])
                ->orderBy('date', 'desc')
                ->get();
        } else {
            $attendance = AttendanceEmployee::where('created_by', $user->creatorId())
                ->with(['employee'])
                ->orderBy('date', 'desc')
                ->get();
        }

        return $this->success(['attendance' => $attendance], 'Attendance retrieved successfully.');
    }

    public function markAttendance(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'clock_in' => 'nullable|date_format:H:i',
            'clock_out' => 'nullable|date_format:H:i',
            'date' => 'nullable|date|date_format:Y-m-d',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 422);
        }

        // Check IP restriction if enabled
        $settings = Utility::settings();
        if (isset($settings['ip_restrict']) && $settings['ip_restrict'] == 'on') {
            $userIp = $request->ip();
            $ip = IpRestrict::where('created_by', Auth::user()->creatorId())
                ->whereIn('ip', [$userIp])
                ->first();
            
            if (empty($ip)) {
                return $this->error('This IP is not allowed to clock in & clock out.', 403);
            }
        }

        $employeeId = !empty(Auth::user()->employee) ? Auth::user()->employee->id : 0;
        $date = $request->date ?: date('Y-m-d');
        $time = date('H:i:s');

        // Get company time settings
        $startTime = Utility::getValByName('company_start_time');
        $endTime = Utility::Utility::getValByName('company_end_time');

        // Check for existing attendance for the day
        $existingAttendance = AttendanceEmployee::where('employee_id', $employeeId)
            ->where('date', $date)
            ->first();

        if ($existingAttendance && $existingAttendance->clock_out != '00:00:00') {
            return $this->error('Employee already clocked out for today.', 400);
        }

        // Calculate times
        $clockInTime = $request->clock_in ?: $time;
        $clockOutTime = $request->clock_out ?: '00:00:00';
        
        $late = '00:00:00';
        $earlyLeaving = '00:00:00';
        $overtime = '00:00:00';

        if ($clockInTime && $clockInTime != '00:00:00') {
            $totalLateSeconds = strtotime($date . ' ' . $clockInTime) - strtotime($date . ' . $startTime);
            $totalLateSeconds = max($totalLateSeconds, 0);
            
            $hours = floor($totalLateSeconds / 3600);
            $mins = floor($totalLateSeconds / 60 % 60);
            $secs = floor($totalLateSeconds % 60);
            $late = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);
        }

        if ($clockOutTime && $clockOutTime != '00:00:00') {
            $totalEarlyLeavingSeconds = strtotime($date . ' . $endTime) - strtotime($date . ' . $clockOutTime);
            $totalEarlyLeavingSeconds = max($totalEarlyLeavingSeconds, 0);
            
            $hours = floor($totalEarlyLeavingSeconds / 3600);
            $mins = floor($totalEarlyLeavingSeconds / 60 % 60);
            $secs = floor($totalEarlyLeavingSeconds % 60);
            $earlyLeaving = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);

            if (strtotime($date . ' ' . $clockOutTime) > strtotime($date . ' . $endTime)) {
                $totalOvertimeSeconds = strtotime($date . ' . $clockOutTime) - strtotime($date . ' . $endTime);
                $hours = floor($totalOvertimeSeconds / 3600);
                $mins = floor($totalOvertimeSeconds / 60 % 60);
                $secs = floor($totalOvertimeSeconds % 60);
                $overtime = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);
            }
        }

        // Create or update attendance record
        if ($existingAttendance) {
            $existingAttendance->update([
                'clock_in' => $clockInTime,
                'clock_out' => $clockOutTime,
                'late' => $late,
                'early_leaving' => $earlyLeaving,
                'overtime' => $overtime,
            ]);
            
            return $this->success(['attendance' => $existingAttendance], 'Attendance updated successfully.');
        } else {
            $attendance = new AttendanceEmployee();
            $attendance->employee_id = $employeeId;
            $attendance->date = $date;
            $attendance->status = $clockInTime ? 'Present' : 'Leave';
            $attendance->clock_in = $clockInTime;
            $attendance->clock_out = $clockOutTime;
            $attendance->late = $late;
            $attendance->early_leaving = $earlyLeaving;
            $attendance->overtime = $overtime;
            $attendance->total_rest = '00:00:00';
            $attendance->created_by = Auth::user()->creatorId();
            $attendance->save();

            return $this->success(['attendance' => $attendance], 'Attendance marked successfully.');
        }
    }

    public function bulkAttendance(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'date' => 'required|date|date_format:Y-m-d',
            'employees' => 'required|array',
            'employees.*.employee_id' => 'required|exists:employees,id',
            'employees.*.clock_in' => 'nullable|date_format:H:i',
            'employees.*.clock_out' => 'nullable|date_format:H:i',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 422);
        }

        // Get company time settings
        $startTime = Utility::getValByName('company_start_time');
        $endTime = Utility::getValByName('company_end_time');
        $date = $request->date;

        $results = [];
        $errors = [];

        foreach ($request->employees as $employeeData) {
            try {
                $employee = Employee::where('id', $employeeData['employee_id'])
                    ->where('created_by', Auth::user()->creatorId())
                    ->first();

                if (!$employee) {
                    $errors[] = "Employee ID {$employeeData['employee_id']} not found.";
                    continue;
                }

                $clockIn = $employeeData['clock_in'] ?? '00:00:00';
                $clockOut = $clockOut = '00:00:00';
                $status = $clockIn ? 'Present' : 'Leave';

                $late = '00:00:00';
                $earlyLeaving = '00:00:00';
                $overtime = '00:00:00';

                if ($clockIn && $clockIn != '00:00:00') {
                    $totalLateSeconds = strtotime($date . ' ' . $clockIn) - strtotime($date . ' . $startTime);
                    $totalLateSeconds = max($totalLateSeconds, 0);
                    
                    $hours = floor($totalLateSeconds / 3600);
                    $mins = floor($totalLateSeconds / 60 % 60);
                    $secs = floor($totalLateSeconds % 60);
                    $late = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);
                }

                if ($clockOut && $clockOut != '00:00:00') {
                    $totalEarlyLeavingSeconds = strtotime($date . ' . $endTime) - strtotime($date . ' . $clockOut);
                    $totalEarlyLeavingSeconds = max($totalEarlyLeavingSeconds, 0);
                    
                    $hours = floor($totalEarlyLeavingSeconds / 3600);
                    $mins = floor($totalEarlyLeavingSeconds / 60 % 60);
                    $secs = floor($totalEarlyLeavingSeconds % 60);
                    $earlyLeaving = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);

                    if (strtotime($date . ' . $clockOut) > strtotime($date . ' . $endTime)) {
                        $totalOvertimeSeconds = strtotime($date . ' . $clockOut) - strtotime($date . ' . $endTime);
                        $hours = floor($totalOvertimeSeconds / 3600);
                        $mins = floor($totalOvertimeSeconds / 60 % 60);
                        $secs = floor($totalOvertimeSeconds % 60);
                        $overtime = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);
                    }
                }

                // Check for existing attendance
                $existingAttendance = AttendanceEmployee::where('employee_id', $employee->id)
                    ->where('date', $date)
                    ->first();

                if ($existingAttendance) {
                    $existingAttendance->update([
                        'status' => $status,
                        'clock_in' => $clockIn,
                        'clock_out' => $clockOut,
                        'late' => $late,
                        'early_leaving' => $earlyLeaving,
                        'overtime' => $overtime,
                    ]);
                    $attendance = $existingAttendance;
                } else {
                    $attendance = new AttendanceEmployee();
                    $attendance->employee_id = $employee->id;
                    $attendance->date = $date;
                    $attendance->status = $status;
                    $attendance->clock_in = $clockIn;
                    $attendance->clock_out = $clockOut;
                    $attendance->late = $late;
                    $attendance->early_leaving = $earlyLeaving;
                    $attendance->overtime = $overtime;
                    $attendance->total_rest = '00:00:00';
                    $attendance->created_by = Auth::user()->creatorId();
                    $attendance->save();
                }

                $results[] = $attendance;
            } catch (\Exception $e) {
                $errors[] = "Error processing employee {$employeeData['employee_id']}: " . $e->getMessage();
            }
        }

        return $this->success([
            'results' => $results,
            'errors' => $errors
        ], 'Bulk attendance processed.');
    }

    public function getAttendanceDetail($id)
    {
        $attendance = AttendanceEmployee::where('id', $id)
            ->where('created_by', Auth::user()->creatorId())
            ->with(['employee'])
            ->first();

        if (!$attendance) {
            return $this->error('Attendance not found', 404);
        }

        // Check if employee has access to this attendance
        if (Auth::user()->type == 'Employee') {
            $emp = Employee::where('user_id', '=', Auth::user()->id)->first();
            if ($attendance->employee_id != $emp->id) {
                return $this->error('Permission denied.', 403);
            }
        }

        return $this->success(['attendance' => $attendance], 'Attendance detail retrieved.');
    }

    public function updateAttendance(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'clock_in' => 'nullable|date_format:H:i',
            'clock_out' => 'nullable|date_format:H:i',
            'date' => 'nullable|date|date_format:Y-m-d',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 422);
        }

        $attendance = AttendanceEmployee::where('id', $id)
            ->where('created_by', Auth::user()->creatorId())
            ->first();

        if (!$attendance) {
            return $this->error('Attendance not found', 404);
        }

        // Check if employee has access to update this attendance
        if (Auth::user()->type == 'Employee') {
            $emp = Employee::where('user_id', '=', Auth::user()->id)->first();
            if ($attendance->employee_id != $emp->id) {
                return $this->error('Permission denied.', 403);
            }
        }

        // Only allow updating current day's attendance for employees
        if (Auth::user()->type == 'Employee' && $attendance->date != date('Y-m-d')) {
            return $this->error('You can only update current day attendance.', 400);
        }

        // Get company time settings
        $startTime = Utility::getValByName('company_start_time');
        $endTime = Utility::getValByName('company_end_time');
        $date = $request->date ?: $attendance->date;

        $clockIn = $request->clock_in ?: $attendance->clock_in;
        $clockOut = $request->clock_out ?: $attendance->clock_out;

        $late = '00:00:00';
        $earlyLeaving = '00:00:00';
        $overtime = '00:00:00';

        if ($clockIn && $clockIn != '00:00:00') {
            $totalLateSeconds = strtotime($date . ' ' . $clockIn) - strtotime($date . ' . $startTime);
            $totalLateSeconds = max($totalLateSeconds, 0);
            
            $hours = floor($totalLateSeconds / 3600);
            $mins = $totalLateSeconds / 60 % 60;
            $secs = floor($totalLateSeconds % 60);
            $late = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);
        }

        if ($clockOut && $clockOut != '00:00:00') {
            $totalEarlyLeavingSeconds = strtotime($date . ' . $endTime) - strtotime($date . ' . $clockOut);
            $totalEarlyLeavingSeconds = max($totalEarlyLeavingSeconds, 0);
            
            $hours = floor($totalEarlyLeavingSeconds / 3600);
            $mins = floor($totalEarlyLeavingSeconds / 60 % 60);
            $secs = floor($totalEarlyLeavingSeconds % 60);
            $earlyLeaving = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);

            if (strtotime($date . ' ' . $clockOut) > strtotime($date . ' . $endTime)) {
                $totalOvertimeSeconds = strtotime($date . ' . $clockOut) - strtotime($date . ' . $endTime);
                $hours = floor($totalOvertimeSeconds / 3600);
                $mins = floor($totalOvertimeSeconds / 60 % 60);
                $secs = floor($totalOvertimeSeconds % 60);
                $overtime = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);
            }
        }

        $attendance->clock_in = $clockIn;
        $attendance->clock_out = $clockOut;
        $attendance->late = $late;
        $attendance->early_leaving = $earlyLeaving;
        $attendance->overtime = $overtime;
        $attendance->save();

        return $this->success(['attendance' => $attendance], 'Attendance updated successfully.');
    }

    public function deleteAttendance($id)
    {
        $attendance = AttendanceEmployee::where('id', $id)
            ->where('created_by', Auth::user()->creatorId())
            ->first();

        if (!$attendance) {
            return $this->error('Attendance not found', 404);
        }

        // Check if employee has access to delete this attendance
        if (Auth::user()->type == 'Employee') {
            $emp = Employee::where('user_id', '=', Auth::user()->id)->first();
            if ($attendance->employee_id != $emp->id) {
                return $this->error('Permission denied.', 403);
            }
        }

        $attendance->delete();

        return $this->success([], 'Attendance deleted successfully.');
    }

    public function getEmployeeAttendanceList($employeeId)
    {
        // Check if employee belongs to user's company
        $employee = Employee::where('id', $employeeId)
            ->where('created_by', Auth::user()->creatorId())
            ->first();

        if (!$employee) {
            return $this->error('Employee not found or access denied.', 404);
        }

        $attendance = AttendanceEmployee::where('employee_id', $employeeId)
            ->orderBy('date', 'desc')
            ->get();

        return $this->success(['attendance' => $attendance], 'Employee attendance retrieved.');
    }

    public function getAttendanceByDateRange(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date' => 'required|date|date_format:Y-m-d',
            'end_date' => 'required|date|date_format:Y-m-d|after_or_equal:start_date',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 422);
        }

        $query = AttendanceEmployee::whereBetween('date', [$request->start_date, $request->end_date])
            ->with(['employee']);

        if (Auth::user()->type == 'Employee') {
            $emp = Employee::where('user_id', '=', Auth::user()->id)->first();
            $query->where('employee_id', $emp->id);
        } else {
            $query->where('created_by', Auth::user()->creatorId());
        }

        $attendance = $query->orderBy('date', 'desc')->get();

        return $this->success(['attendance' => $attendance], 'Attendance by date range retrieved.');
    }

    public function getAttendanceStats(Request $request)
    {
        $query = AttendanceEmployee::where('created_by', Auth::user()->creatorId());

        if (Auth::user()->type == 'Employee') {
            $emp = Employee::where('user_id', '=', Auth::user()->id)->first();
            $query->where('employee_id', $emp->id);
        }

        $totalDays = $query->count();
        $presentDays = $query->where('status', 'Present')->count();
        $leaveDays = $query->where('status', 'Leave')->count();

        // Calculate total overtime
        $totalOvertime = $query->sum('overtime');
        $totalLate = $query->sum('late');
        $totalEarlyLeaving = $query->sum('early_leaving');

        // Group by employee
        $attendanceByEmployee = $query->with('employee')
            ->get()
            ->groupBy('employee.name')
            ->map(function ($group) {
                return [
                    'employee_name' => $group->first()->employee->name,
                    'total_days' => $group->count(),
                    'present_days' => $group->where('status', 'Present')->count(),
                    'leave_days' => $group->where('status', 'Leave')->count(),
                ];
            });

        // Group by date
        $attendanceByDate = $query->get()
            ->groupBy('date')
            ->map(function ($group) {
                return [
                    'date' => $group->first()->date,
                    'total_attendance' => $group->count(),
                    'present_count' => $group->where('status', 'Present')->count(),
                    'leave_count' => $group->where('status', 'Leave')->count(),
                ];
            });

        return $this->success([
            'total_days' => $totalDays,
            'present_days' => $presentDays,
            'leave_days' => $leaveDays,
            'total_overtime' => $totalOvertime,
            'total_late' => $totalLate,
            'total_early_leaving' => $totalEarlyLeaving,
            'attendance_by_employee' => $attendanceByEmployee,
            'attendance_by_date' => $attendanceByDate
        ], 'Attendance statistics retrieved.');
    }

    public function getMyAttendance()
    {
        if (Auth::user()->type != 'Employee') {
            return $this->error('This endpoint is for employees only.', 403);
        }

        $emp = Employee::where('user_id', '=', Auth::user()->id)->first();
        $attendance = AttendanceEmployee::where('employee_id', $emp->id)
            ->orderBy('date', 'desc')
            ->get();

        return $this->success(['attendance' => $attendance], 'My attendance retrieved.');
    }

    public function getCompanyTimeSettings()
    {
        $startTime = Utility::getValByName('company_start_time');
        $endTime = Utility::getValByName('company_end_time');
        
        return $this->success([
            'start_time' => $startTime,
            'end_time' => $endTime
        ], 'Company time settings retrieved.');
    }

    public function getEmployees()
    {
        $employees = Employee::where('created_by', Auth::user()->creatorId())
            ->get(['id', 'name', 'email']);

        return $this->success(['employees' => $employees], 'Employees retrieved.');
    }

    public function getBranches()
    {
        $branches = Branch::where('created_by', Auth::user()->creatorId())
            ->get(['id', 'name']);

        return $this->success(['branches' => $branches], 'Branches retrieved.');
    }

    public function getDepartments()
    {
        $departments = Department::where('created_by', Auth::user()->creatorId())
            ->get(['id', 'name']);

        return $this->success(['departments' => $departments], 'Departments retrieved.');
    }
}
