<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Employee;
use App\Models\User;
use App\Models\Department;
use App\Models\Designation;
use App\Models\Branch;
use App\Traits\ApiResponser;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\Utility;

class EmployeeApiController extends Controller
{
    use ApiResponser;

    public function index()
    {
        if (Auth::user()->type == 'Employee') {
            $employees = Employee::where('user_id', '=', Auth::user()->id)->with(['designation', 'branch', 'department'])->get();
        } else {
            $employees = Employee::where('created_by', Auth::user()->creatorId())->with(['designation', 'branch', 'department'])->get();
        }

        return $this->success(['employees' => $employees], 'Employees retrieved successfully.');
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'dob' => 'required',
            'phone' => 'required',
            'address' => 'required',
            'email' => 'required|unique:users',
            'password' => 'required',
            'branch_id' => 'required',
            'department_id' => 'required',
            'designation_id' => 'required',
            'company_doj' => 'required',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 401);
        }

        $creatorId = Auth::user()->creatorId();
        $objUser = User::find($creatorId);

        // Simplified creation without plan checks for API v1
        $user = User::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
            'type' => 'employee',
            'lang' => 'en',
            'created_by' => $creatorId,
            'email_verified_at' => date('Y-m-d H:i:s'),
        ]);
        $user->assignRole('Employee');

        $employee = Employee::create([
            'user_id' => $user->id,
            'name' => $request['name'],
            'dob' => $request['dob'],
            'gender' => $request['gender'] ?? null,
            'phone' => $request['phone'],
            'address' => $request['address'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
            'employee_id' => $this->employeeNumber(),
            'branch_id' => $request['branch_id'],
            'department_id' => $request['department_id'],
            'designation_id' => $request['designation_id'],
            'company_doj' => $request['company_doj'],
            'created_by' => $creatorId,
        ]);

        return $this->success(['employee' => $employee], 'Employee created successfully.');
    }

    public function show($id)
    {
        $employee = Employee::with(['designation', 'branch', 'department', 'documents', 'salaryType'])->find($id);

        if (!$employee) {
            return $this->error('Employee not found.', 404);
        }

        return $this->success(['employee' => $employee], 'Employee retrieved successfully.');
    }

    public function update(Request $request, $id)
    {
        $employee = Employee::find($id);

        if (!$employee) {
            return $this->error('Employee not found.', 404);
        }

        $input = $request->all();
        $employee->fill($input)->save();

        if ($employee->user_id) {
            $user = User::find($employee->user_id);
            if ($user) {
                $user->name = $employee->name;
                if ($request->email) $user->email = $employee->email;
                $user->save();
            }
        }

        return $this->success(['employee' => $employee], 'Employee updated successfully.');
    }

    public function destroy($id)
    {
        $employee = Employee::find($id);

        if (!$employee) {
            return $this->error('Employee not found.', 404);
        }

        if ($employee->user_id) {
            $user = User::find($employee->user_id);
            if ($user) $user->delete();
        }

        $employee->delete();

        return $this->success([], 'Employee deleted successfully.');
    }

    function employeeNumber()
    {
        $latest = Employee::where('created_by', '=', Auth::user()->creatorId())->max('employee_id');
        return $latest ? $latest + 1 : 1;
    }

    public function getEmployeeDocuments($id)
    {
        $documents = \App\Models\EmployeeDocument::where('employee_id', $id)->get();
        return $this->success(['documents' => $documents], 'Documents retrieved successfully.');
    }

    public function uploadEmployeeDocument(Request $request, $id)
    {
        $validator = \Validator::make($request->all(), [
            'document_id' => 'required',
            'document_file' => 'required|file',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 401);
        }

        $document = new \App\Models\EmployeeDocument();
        $document->employee_id = $id;
        $document->document_id = $request->document_id;

        if ($request->hasFile('document_file')) {
            $filenameWithExt = $request->file('document_file')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('document_file')->getClientOriginalExtension();
            $fileNameToStore = $filename . '_' . time() . '.' . $extension;
            $dir = storage_path('uploads/document');
            if (!file_exists($dir)) mkdir($dir, 0777, true);
            $request->file('document_file')->storeAs('uploads/document', $fileNameToStore);
            $document->document_value = $fileNameToStore;
        }

        $document->created_by = Auth::user()->creatorId();
        $document->save();

        return $this->success(['document' => $document], 'Document uploaded successfully.');
    }

    public function getEmployeeSalary($id)
    {
        $employee = Employee::find($id);
        if (!$employee) return $this->error('Employee not found.', 404);

        $salaryData = [
            'salary' => $employee->salary,
            'salary_type' => $employee->salary_type, // This uses the relation accessor, might need raw id
            'salary_type_id' => $employee->attributes['salary_type'] ?? null, // Access raw attribute if needed
            'net_salary' => $employee->get_net_salary(),
            'allowances' => $employee->allowances,
            'commissions' => $employee->commissions,
            'loans' => $employee->loans,
            'saturation_deductions' => $employee->saturationDeductions,
            'other_payments' => $employee->otherPayments,
            'overtimes' => $employee->overtimes,
        ];

        return $this->success(['salary_data' => $salaryData], 'Employee salary data retrieved.');
    }

    public function setEmployeeSalary(Request $request, $id)
    {
        $validator = \Validator::make($request->all(), [
            'salary_type' => 'required',
            'salary' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 401);
        }

        $employee = Employee::find($id);
        if (!$employee) return $this->error('Employee not found.', 404);

        $employee->salary_type = $request->salary_type;
        $employee->salary = $request->salary;
        $employee->save();

        return $this->success(['employee' => $employee], 'Employee salary updated successfully.');
    }

    public function getEmployeeLeaves($id)
    {
        $leaves = \App\Models\Leave::where('employee_id', $id)->get();
        return $this->success(['leaves' => $leaves], 'Employee leaves retrieved.');
    }

    public function getEmployeePayslips($id)
    {
        $payslips = \App\Models\PaySlip::where('employee_id', $id)->get();
        return $this->success(['payslips' => $payslips], 'Employee payslips retrieved.');
    }

    public function importEmployees(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'file' => 'required|file|mimes:csv,txt',
            'column_mapping' => 'required|array',
            'column_mapping.*' => 'required|string|in:name,dob,gender,phone,address,email,password,company_doj,account_holder_name,account_number,bank_name,bank_identifier_code,branch_location,tax_payer_id,branch_id,department_id,designation_id',
        ]);

        if ($validator->fails()) {
            return $this->error($validator->errors()->first(), 422);
        }

        if (!$request->hasFile('file')) {
            return $this->error('No file provided.', 400);
        }

        $file = $request->file('file');
        $filePath = $file->getRealPath();
        $file_extension = $file->getClientOriginalExtension();

        if ($file_extension !== 'csv') {
            return $this->error('Only CSV files are supported.', 400);
        }

        try {
            $file_data = [];
            $header = null;

            if (($handle = fopen($filePath, 'r')) !== FALSE) {
                while (($row = fgetcsv($handle, 1000, ',')) !== FALSE) {
                    if (!$header) {
                        $header = $row;
                    } else {
                        $file_data[] = $row;
                    }
                }
                fclose($handle);
            }

            $columnMapping = $request->column_mapping;
            $results = [];
            $errors = [];
            $successCount = 0;
            $errorCount = 0;

            foreach ($file_data as $key => $row) {
                try {
                    // Check if employee with this email already exists
                    $emailColumn = array_search('email', $columnMapping);
                    if ($emailColumn !== false && !empty($row[$emailColumn])) {
                        $existingEmployee = Employee::where('created_by', Auth::user()->creatorId())
                            ->where('email', 'like', $row[$emailColumn])
                            ->first();

                        if ($existingEmployee) {
                            $errors[] = "Row " . ($key + 2) . ": Employee with email '{$row[$emailColumn]}' already exists.";
                            $errorCount++;
                            continue;
                        }
                    }

                    // Validate required fields
                    $nameColumn = array_search('name', $columnMapping);
                    $emailColumn = array_search('email', $columnMapping);
                    $passwordColumn = array_search('password', $columnMapping);

                    if ($nameColumn === false || empty($row[$nameColumn])) {
                        $errors[] = "Row " . ($key + 2) . ": Name is required.";
                        $errorCount++;
                        continue;
                    }

                    if ($emailColumn === false || empty($row[$emailColumn])) {
                        $errors[] = "Row " . ($key + 2) . ": Email is required.";
                        $errorCount++;
                        continue;
                    }

                    if ($passwordColumn === false || empty($row[$passwordColumn])) {
                        $errors[] = "Row " . ($key + 2) . ": Password is required.";
                        $errorCount++;
                        continue;
                    }

                    // Create user account
                    $user = \App\Models\User::create([
                        'name' => $row[$nameColumn],
                        'email' => $row[$emailColumn],
                        'password' => \Hash::make($row[$passwordColumn]),
                        'email_verified_at' => date('Y-m-d H:i:s'),
                        'type' => 'Employee',
                        'lang' => 'en',
                        'created_by' => Auth::user()->creatorId(),
                    ]);

                    $user->assignRole('Employee');

                    // Prepare employee data
                    $employeeData = [
                        'name' => $row[$nameColumn],
                        'user_id' => $user->id,
                        'email' => $row[$emailColumn],
                        'password' => \Hash::make($row[$passwordColumn]),
                        'employee_id' => $this->generateEmployeeNumber(),
                        'created_by' => Auth::user()->creatorId(),
                    ];

                    // Add optional fields
                    $optionalFields = [
                        'dob' => 'dob',
                        'gender' => 'gender',
                        'phone' => 'phone',
                        'address' => 'address',
                        'company_doj' => 'company_doj',
                        'account_holder_name' => 'account_holder_name',
                        'account_number' => 'account_number',
                        'bank_name' => 'bank_name',
                        'bank_identifier_code' => 'bank_identifier_code',
                        'branch_location' => 'branch_location',
                        'tax_payer_id' => 'tax_payer_id',
                    ];

                    foreach ($optionalFields as $field => $column) {
                        $columnIndex = array_search($column, $columnMapping);
                        if ($columnIndex !== false && !empty($row[$columnIndex])) {
                            $employeeData[$field] = $row[$columnIndex];
                        }
                    }

                    // Handle relationships
                    $branchColumn = array_search('branch_id', $columnMapping);
                    if ($branchColumn !== false && !empty($row[$branchColumn])) {
                        $branch = \App\Models\Branch::find($row[$branchColumn]);
                        if ($branch && $branch->created_by == Auth::user()->creatorId()) {
                            $employeeData['branch_id'] = $branch->id;
                        }
                    }

                    $departmentColumn = array_search('department_id', $columnMapping);
                    if ($departmentColumn !== false && !empty($row[$departmentColumn])) {
                        $department = \App\Models\Department::find($row[$departmentColumn]);
                        if ($department && $department->created_by == Auth::user()->creatorId()) {
                            $employeeData['department_id'] = $department->id;
                        }
                    }

                    $designationColumn = array_search('designation_id', $columnMapping);
                    if ($designationColumn !== false && !empty($row[$designationColumn])) {
                        $designation = \App\Models\Designation::find($row[$designationColumn]);
                        if ($designation && $designation->created_by == Auth::user()->creatorId()) {
                            $employeeData['designation_id'] = $designation->id;
                        }
                    }

                    // Create employee
                    $employee = Employee::create($employeeData);
                    $results[] = [
                        'row' => $key + 2,
                        'name' => $employee->name,
                        'email' => $employee->email,
                        'status' => 'success'
                    ];
                    $successCount++;
                } catch (\Exception $e) {
                    $errors[] = "Row " . ($key + 2) . ": " . $e->getMessage();
                    $errorCount++;
                }
            }

            return $this->success([
                'results' => $results,
                'errors' => $errors,
                'summary' => [
                    'total_rows' => count($file_data),
                    'success_count' => $successCount,
                    'error_count' => $errorCount
                ]
            ], 'Employee import completed.');
        } catch (\Exception $e) {
            return $this->error('Error processing file: ' . $e->getMessage(), 500);
        }
    }

    public function exportEmployees()
    {
        try {
            $employees = Employee::where('created_by', Auth::user()->creatorId())
                ->with(['branch', 'department', 'designation'])
                ->get();

            $csvData = [];
            $csvData[] = [
                'Name',
                'Email',
                'Phone',
                'Address',
                'DOB',
                'Gender',
                'Employee ID',
                'Company DOJ',
                'Account Holder Name',
                'Account Number',
                'Bank Name',
                'Bank Identifier Code',
                'Branch Location',
                'Tax Payer ID',
                'Branch',
                'Department',
                'Designation'
            ];

            foreach ($employees as $employee) {
                $csvData[] = [
                    $employee->name,
                    $employee->email,
                    $employee->phone,
                    $employee->address,
                    $employee->dob,
                    $employee->gender,
                    $employee->employee_id,
                    $employee->company_doj,
                    $employee->account_holder_name,
                    $employee->account_number,
                    $employee->bank_name,
                    $employee->bank_identifier_code,
                    $employee->branch_location,
                    $employee->tax_payer_id,
                    $employee->branch ? $employee->branch->name : '',
                    $employee->department ? $employee->department->name : '',
                    $employee->designation ? $employee->designation->name : '',
                ];
            }

            $filename = 'employees_' . date('Y-m-d_H-i-s') . '.csv';

            $headers = [
                'Content-Type' => 'text/csv',
                'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            ];

            $callback = function () use ($csvData) {
                $file = fopen('php://output', 'w');
                foreach ($csvData as $row) {
                    fputcsv($file, $row);
                }
                fclose($file);
            };

            return response()->stream($callback, 200, $headers);
        } catch (\Exception $e) {
            return $this->error('Error exporting employees: ' . $e->getMessage(), 500);
        }
    }

    private function generateEmployeeNumber()
    {
        $lastEmployee = Employee::orderBy('id', 'desc')->first();
        $lastNumber = $lastEmployee ? intval(substr($lastEmployee->employee_id, -4)) : 0;
        $newNumber = str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);
        return 'EMP' . date('Y') . $newNumber;
    }
}
